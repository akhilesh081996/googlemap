module.exports = {
    visitorDB: require("./visitorModel"),
    countDB: require("./countModel"),
    testDB: require("./testModel"),
    userDB: require("./userModel")
};